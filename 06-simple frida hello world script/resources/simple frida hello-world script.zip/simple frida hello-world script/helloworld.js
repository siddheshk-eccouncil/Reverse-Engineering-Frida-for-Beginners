
Java.perform(()=>{
    console.log("hello world, bye");
});