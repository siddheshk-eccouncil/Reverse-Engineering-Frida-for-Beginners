const modulearray = Process.enumerateModules();

for(var i=0; i<modulearray.length; i++){
    console.log(modulearray[i].name);
}
